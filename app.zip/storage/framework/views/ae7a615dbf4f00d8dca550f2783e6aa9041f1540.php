<?php $__env->startSection('content'); ?>

		    		
		    		<div class="page-title title-1">
						<div class="container">
							<div class="row">
								<h1>Portfolio Grid Layout</h1>
								<h3>This is sub heading text to describe the page functionality</h3>
								
								<div class="breadcrumbs">
									<a href="#">Home</a><i class="fa fa-long-arrow-right main-color"></i><a href="#">Portfolio</a><i class="fa fa-long-arrow-right main-color"></i><span>Portfolio Grid Layout</span>
								</div>
								
							</div>
						</div>
					</div>
					
					<div class="section">
						<div class="container">
							<div class="filter-by">
								<ul id="filters">
                                    <li class="active shape"><a href="#" class="filter" data-filter="*">All</a></li>
                                    <li class="shape"><a href="#" class="filter" data-filter=".design">Web Design</a></li>
                                    <li class="shape"><a href="#" class="filter" data-filter=".develop">Web Development</a></li>
                                    <li class="shape"><a href="#" class="filter" data-filter=".computers">Computers</a></li>
                                </ul>
							</div>
							<div class="portfolio p-4-cols simple" id="container">
								
								<div class="portfolio-item develop">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/1.jpg" class="zoom shape" title="Quality Products for Companies"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/1.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">Quality Products for Companies</a></h4>
										<h5><a href="#">Design</a>, <a href="#">Development</a></h5>
									</div>
								</div>
								<div class="portfolio-item design">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/2.jpg" class="zoom shape" title="Nature vs. Man"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/2.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">Nature vs. Man</a></h4>
										<h5><a href="#">Design</a>, <a href="#">Development</a></h5>
									</div>
								</div>
								<div class="portfolio-item develop">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/3.jpg" class="zoom shape" title="A Day with Sunshine & Bliss"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/3.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">A Day with Sunshine & Bliss</a></h4>
										<h5><a href="#">Design</a>, <a href="#">Development</a></h5>
									</div>
								</div>
								<div class="portfolio-item develop computers">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/4.jpg" class="zoom shape" title="A Workplace for Champions"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/4.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">A Workplace for Champions</a></h4>
										<h5><a href="#">Design</a>, <a href="#">Development</a></h5>
									</div>
								</div>
								<div class="portfolio-item design">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/5.jpg" class="zoom shape" title="Doing it the Chilled Way"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/5.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">Doing it the Chilled Way</a></h4>
										<h5><a href="#">Just Food</a>, <a href="#">Development</a></h5>
									</div>
								</div>
								<div class="portfolio-item develop computers">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/6.jpg" class="zoom shape" title="Take a Ride in a Luxury Car"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/6.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">Take a Ride in a Luxury Car</a></h4>
										<h5><a href="#">Hipster Content</a>, <a href="#">Just Food</a></h5>
									</div>
								</div>
								<div class="portfolio-item design">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/7.jpg" class="zoom shape" title="The Long Way to the Top"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/7.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">The Long Way to the Top</a></h4>
										<h5><a href="#">News</a>, <a href="#">Computers</a></h5>
									</div>
								</div>
								<div class="portfolio-item computers">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/8.jpg" class="zoom shape" title="The Pro Work Solution"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/8.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">The Pro Work Solution</a></h4>
										<h5><a href="#">Company News</a>, <a href="#">Hipster Content</a></h5>
									</div>
								</div>
								<div class="portfolio-item develop">
									<div class="img-holder">
										<div class="img-over">
											<a href="portfolio-single.html" class="link shape"><i class="fa fa-link"></i></a>
											<a href="images/portfolio/large/9.jpg" class="zoom shape" title="Hand Crafted Premium Watch"><i class="fa fa-search-plus"></i></a>
										</div>
										<img alt="" src="images/portfolio/small/9.jpg">
									</div>
									<div class="name-holder">
										<h4><a href="portfolio-single.html" class="main-color">Hand Crafted Premium Watch</a></h4>
										<h5><a href="#">Just food</a></h5>
									</div>
								</div>
								
							</div>
						</div>
					</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>