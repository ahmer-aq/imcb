<?php $__env->startSection('content'); ?>
<div class="clearfix">
                  <div class="camera_wrap camera_magenta_skin camera-slider margin-bottom-0">
                     <div data-thumb="images/sliders/thumbs/1.jpg" data-src="images/sliders/1.jpg">
                        <div class="camera_caption fadeFromBottom">
                           Stricken Chinese cruise ship lifted from Yangtze River
                        </div>
                     </div>
                     <div data-thumb="images/sliders/thumbs/2.jpg" data-src="images/sliders/2.jpg">
                        <div class="camera_caption fadeFromBottom">
                           Stricken Chinese cruise ship lifted from Yangtze River
                        </div>
                     </div>
                     <div data-thumb="images/sliders/thumbs/3.jpg" data-src="images/sliders/3.jpg">
                        <div class="camera_caption fadeFromBottom">
                           Stricken Chinese cruise ship lifted from Yangtze River
                        </div>
                     </div>
                      <div data-thumb="images/sliders/thumbs/3.jpg" data-src="images/sliders/4.jpg">
                        <div class="camera_caption fadeFromBottom">
                           Stricken Chinese cruise ship lifted from Yangtze River
                        </div>
                     </div>
                  </div>
               </div>
               <center>
                  <div class="main-bg pad-top zero-p-m">
                     <blockquote class="bquote-2">
                        <p >orem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus eget lacus sit amet neque posuere aliquet.orem ipsum dolor sit ame...</p>
                        <span class="white">- Mark Henry "Google.com"</span>
                     </blockquote>
                  </div>
               </center>
               <!-- /////////////////////////////////////////////////////////////////////// -->
               <!-- Our Mission -->
               <div class="tabs-style-lg style-1 gry-bg">
                  <div class="container">
                     <ul class="nav nav-tabs" role="tablist">
                        <li  id="presentation" role="presentation" class="active"><a class="uppercase" href="#message-5"><span><i class="fa fa-briefcase main-color tab-icon shape"></i>Principal Message</span></a></li>
                        <li  id="presentation" role="presentation"><a class="uppercase" href="#mission-5"><span><i class="fa fa-briefcase main-color tab-icon shape"></i>Our Mission</span></a></li>
                        <li  id="presentation" role="presentation"><a class="uppercase" href="#vision-5"><span><i class="fa fa-eye main-color tab-icon shape"></i>Our Vision</span></a></li>
                        <li  id="presentation" role="presentation"><a class="uppercase" href="#strategy-5"><span><i class="fa fa-cogs main-color tab-icon shape"></i>Our Strategy</span></a></li>
                     </ul>
                  </div>
                  <div class="lg-tab-content black-bg parallax" style="background-image:url('images/bgs/bg-01.jpg')" data-stellar-background-ratio="0.4" data-overlay="rgba(0,0,0,.4)">
                     <div class="container">
                        <div class="tab-content section">
                           <div role="tabpanel" class="tab-pane fade in active" id="message-5">
                              <div class="row">
                                 <div class="col-md-5">
                                    <img alt="" class="bordered-img shape lg main-border" src="images/team/dr_muhammad_sher.jpg" />
                                 </div>
                                 <div class="col-md-7 lg-tab-txt">
                                    <h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
                                    Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa.<br> cursus massa at urnaaculis estie.Mauris in quam tristique, dignissim urna in, molestie felis.<br> Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.
                                 </div>
                              </div>
                           </div>
                           <div role="tabpanel" class="tab-pane fade in" id="mission-5">
                              <div class="row">
                                 <div class="col-md-5">
                                    <img alt="" class="bordered-img shape lg main-border" src="images/features/08.jpg" />
                                 </div>
                                 <div class="col-md-7 lg-tab-txt">
                                    <h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
                                    Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa.<br> cursus massa at urnaaculis estie.Mauris in quam tristique, dignissim urna in, molestie felis.<br> Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.
                                 </div>
                              </div>
                           </div>
                           <div role="tabpanel" class="tab-pane fade" id="vision-5">
                              <div class="row">
                                 <div class="col-md-7 lg-tab-txt">
                                    <h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
                                    <p>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce odio, molestie felis Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris.</p>
                                    <ol class="f-left ollist">
                                       <li>vehicula imperdiet, eros est egestas odio</li>
                                       <li>Fusce odio, at aliquet </li>
                                       <li>vehicula eros est egestas odio</li>
                                       <li>Fusce odio, at aliquet </li>
                                    </ol>
                                 </div>
                                 <div class="col-md-5">
                                    <img alt="" class="bordered-img shape lg main-border" src="images/portfolio/masonry/2.jpg" />
                                 </div>
                              </div>
                           </div>
                           <div role="tabpanel" class="tab-pane fade" id="strategy-5">
                              <div class="row">
                                 <div class="col-md-5">
                                    <img alt="" class="bordered-img shape lg main-border" src="images/portfolio/masonry/4.jpg" />
                                 </div>
                                 <div class="col-md-7 lg-tab-txt">
                                    <h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
                                    <p>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce odio, at aliquet elit nulla sed massa Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris.</p>
                                    <ul class="ullist">
                                       <li>vehicula imperdiet, eros est egestas odio</li>
                                       <li>Fusce odio, at aliquet </li>
                                       <li>vehicula eros est egestas odio</li>
                                       <li>Fusce odio, at aliquet </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- /////////////////////Our M ission End/////////////////////////////// -->
               <div class="parallax" style="background:transparent url('images/bgs/sec-bg-01.jpg')" data-stellar-background-ratio="0.6">
                  <div class="container">
                     <div class="row row-eq-height">
                        <div class="col-md-3 padding-vertical-20">
                           <div class="section-full-bg left main-bg rect"></div>
                           <div class="white-bg bg-block main-border shape lg">
                              <div class="heading sub-head">
                                 <h3 class="head-4 bolder uppercase">Some <span class="main-color">Facts</span></h3>
                              </div>
                              <p>Some Facts about IMCB : Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt voluptatum impedit illum doloribus consequatur autem placeat, voluptatem ut et, corporis voluptatibus alias necessitatibus atque! Odio delectus nisi, animi obcaecati aut.</p>
                           </div>
                        </div>
                        <div class="col-md-9 padding-vertical-80">
                           <div class="row">
                              <div class="col-md-3">
                                 <div class="pink-bg fun-icon lg-icon shape"><i class="fa fa-users"></i></div>
                                 <div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="2500" data-timer="500"></div>
                                 <div class="fun-info t-center">Students</div>
                              </div>
                              <div class="col-md-3">
                                 <div class="green-bg fun-icon lg-icon shape"><i class="fa fa-umbrella"></i></div>
                                 <div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="25" data-timer="500"></div>
                                 <div class="fun-info t-center">Busses</div>
                              </div>
                              <div class="col-md-3">
                                 <div class="blue-bg fun-icon lg-icon shape"><i class="fa fa-clock-o"></i></div>
                                 <div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="60" data-timer="500"></div>
                                 <div class="fun-info t-center">60 Staff members</div>
                              </div>
                              <div class="col-md-3">
                                 <div class="orange-bg fun-icon lg-icon shape"><i class="fa fa-coffee"></i></div>
                                 <div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="1992" data-timer="500"></div>
                                 <div class="fun-info t-center">Since 1992</div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- \\\\\\\\\\\\\\\\\\\\\\\\\INTRODUCTION\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ -->
               <div class="page-title title-1">
                  <div class="container">
                     <div class="row">
                        <h1>Header Style 3</h1>
                        <h3>This is sub heading text to describe the page functionality</h3>
                        <div class="breadcrumbs">
                           <a href="#">Home</a><i class="fa fa-long-arrow-right main-color"></i><a href="#">Pages</a><i class="fa fa-long-arrow-right main-color"></i><span>Header Style 3</span>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="section">
                  <div class="container">
                     <div class="row">
                        <div class="col-md-12">
                           <p>
                              Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.
                           </p>
                           <p>
                              Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, <a href="#">consectetur adipiscing</a> elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.
                           </p>
                           <blockquote class="bquote-1">
                              <p>Phasellus tristique libero vel justo aliquam pellentesque. Maecenas vestibulum velit est, in tincidunt arcu fermentum id. Morbi ipsum arcu, iaculis nec sapien vel, egestas viverra eros. Phasellus ac dolor elit.</p>
                              <span class="main-color">- Mark Henry "Google.com"</span>
                           </blockquote>
                           <p>
                              <br>
                              Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollisNullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollisNullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollisNullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis.Lorem ipsum dolor sit amet, co sectetur adipiscing elit. Nullam convallis euismod mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nlis euismod mollis. Nullam convallis euismod mollis.
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>