<!DOCTYPE html>
<html>
	

<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>SuperFine | Multi-purpose HTML5 Template</title>
		<meta name="description" content="SuperFine | Multi-purpose HTML5 Template">
		<meta name="author" content="IT-RAYS">
		
		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		
		<!-- Put favicon.ico and apple-touch-icon(s).png in the images folder -->
	    <link rel="shortcut icon" href="images/favicon.ico">
		    	
		<!-- CSS StyleSheets -->
		<link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/assets.css">
		
		<link rel="stylesheet" href="css/style.css">
		<link id="theme_css" rel="stylesheet" href="css/dark.css">
		
		<!--[if lt IE 9]>
	    	<script type="text/javascript" src="js/html5.js"></script>
	    <![endif]-->
		
		<!-- Skin CSS file -->
		<link id="skin_css" rel="stylesheet" href="css/skins/default.css">

		
	</head>
	<body>

		
		<div class="pageWrapper animsition">
			
			<!-- top bar start -->
	    	<div class="top-bar main-bg">
			    <div class="container">
					    
				    <div class="center-tbl">
				    	
				    	<ul class="top-info">
						    <li><a href="#" class="shape"><i class="fa fa-envelope"></i>email@domain.com</a></li>
						    <li><span><i class="fa fa-phone"></i> +1 (888) 000-0000</span></li>
					    </ul>
				    	
					    <ul class="social-list middle-ul alter-bg shape">
						    <li><a href="#" class="fa fa-dribbble" data-tooltip="true" data-title="dribbble" data-position="bottom"></a></li>
						    <li><a href="#" class="fa fa-facebook" data-tooltip="true" data-title="facebook" data-position="bottom"></a></li>
						    <li><a href="#" class="fa fa-linkedin" data-tooltip="true" data-title="linkedin" data-position="bottom"></a></li>
						    <li><a href="#" class="fa fa-skype" data-tooltip="true" data-title="skype" data-position="bottom"></a></li>
						    <li><a href="#" class="fa fa-twitter" data-tooltip="true" data-title="twitter" data-position="bottom"></a></li>
					    </ul>
					    
					    <ul>
						    <li class="dropdown"><a href="#" class="shape" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="login-bx"><i class="fa fa-lock"></i>Login</a>
						    	<div class="dropdown-menu login-popup black-bg">
									<p class="small">Hello our valued visitor, We present you the best web solutions, just login ...</p>
									<div class="login-controls">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="User name Or Email" />
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Password" />
										</div>
										<div class="form-group floated-controls">
											<span class="block checkbox-block"><input type="checkbox" class="checkbox" /> <span>Remember Me!</span></span>
											<a href="#">Forgot your password ?</a>
										</div>
										<div>
											<button type="button" class="btn main-bg">Submit</button>
										</div>
									</div>
								</div>
						    </li>
						    <li><a href="#" class="shape" data-toggle="modal" data-target="#registermodal"><i class="fa fa-user"></i> Register</a></li>
						    <li><a class="shape" href="sitemap.html"><i class="fa fa-sitemap"></i> Site map</a></li>
					    </ul>
					    
				    </div>
											    
			    </div>
		    </div>
		    <!-- top bar end -->
			
			<header class="top-head header-3" data-sticky="true">
		    	<div class="container">
			    	<!-- Logo start -->
			    	<div class="logo" style="padding-bottom: 0px;padding-top: 0px">
				    	<a href="index.html"><img alt="" src="images/logo.png"  /></a>
				    </div>
				   <center><div class="remove-that hr-bgc" ></div></center>

				    <!-- Logo end -->
					<div class="full responsive-nav">
						<!-- top navigation menu start -->
						<nav class="top-nav nav-animate to-bottom" >
							<ul>
								<li><a href="#">Home</a></li>
								<li><a href="#">Faculty</a>
									<ul>
										<li><a href="#">Blog Large Image</a>
											<ul>
												<li><a href="blog.html">Right Side Bar</a></li>
												<li><a href="blog-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-no-bar.html">No side bar</a></li>
											</ul>
										</li>
										<li><a href="#">Blog Small Image</a>
											<ul>
												<li><a href="blog-thumbnails.html">Right Side Bar</a></li>
												<li><a href="blog-thumbnails-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-thumbnails-no-bar.html">No side bar</a></li>
											</ul>
										</li>
										<li><a href="#">Blog Timeline</a>
											<ul>
												<li><a href="blog-timeline.html">Right Side Bar</a></li>
												<li><a href="blog-timeline-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-timeline-no-bar.html">No side bar</a></li>
											</ul>
										</li>
										<li><a href="#">Blog masonry</a>
											<ul>
												<li><a href="blog-masonry.html">Right Side Bar</a></li>
												<li><a href="blog-masonry-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-masonry-no-bar.html">No side bar</a></li>
											</ul>
										</li>
										<li><a href="#">Blog Grid</a>
											<ul>
												<li><a href="blog-grid.html">Right Side Bar</a></li>
												<li><a href="blog-grid-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-grid-no-bar.html">No side bar</a></li>
											</ul>
										</li>
										<li><a href="#">Blog Single</a>
											<ul>
												<li><a href="blog-single.html">Right Side Bar</a></li>
												<li><a href="blog-single-left-bar.html">Left Side Bar</a></li>
												<li><a href="blog-single-no-bar.html">No side bar</a></li>
											</ul>
										</li>
									
									</ul>
								</li>
								<li><a href="#">Gallary</a></li>
								<li><a href="#">Addmission</a></li>
								<li><a href="#">Results</a></li>
								<li><a href="#">Publications</a></li>
								<li><a href="#">Prefectorial</a></li>
								<li><a href="#">Contact Us</a></li>
							</ul>
						</nav >
						<!-- top navigation menu end -->
				
					</div>
		    	</div>
		    </header>
	    			<!-- top bar start -->
	    	<div class=" main-bg">
			    <div class="container">
					    
				    <div class="center-tbl breaking-news" style="width: 100%!important">
				    	
				    	<div class="break-news shape">
						<span class="lbl">Breaking News</span>
						<div class="break-news-slider">
							<div>
								<a href="#">Stricken Chinese cruise ship lifted from Yangtze River</a>
							</div>
							<div>
								<a href="#">Spectacular, rarely seen images of China's railways</a>
							</div>
							<div>
								<a href="#">Most climbers on Malaysia peak reach safety after quake</a>
							</div>
							<div>
								<a href="#">Bradley Wiggins: Why cycling's hour record 'is made for Brit to break'</a>
							</div>
						</div>
					</div>
					    
				    </div>
											    
			    </div>
		    </div>
		    <!-- top bar end -->
		    		    
		    <div id="contentWrapper">
		    
		    	<div class="pageContent">
		    		<div class="clearfix">
						<div class="camera_wrap camera_magenta_skin camera-slider margin-bottom-0">
				            <div data-thumb="images/sliders/others/thumbs/1.jpg" data-src="images/sliders/others/1.jpg">
				            	<div class="camera_caption fadeFromBottom">
				                    Stricken Chinese cruise ship lifted from Yangtze River
				                </div>
				            </div>
				            <div data-thumb="images/sliders/others/thumbs/2.jpg" data-src="images/sliders/others/2.jpg">
				            	<div class="camera_caption fadeFromBottom">
				                    Stricken Chinese cruise ship lifted from Yangtze River
				                </div>
				            </div>
				            <div data-thumb="images/sliders/others/thumbs/3.jpg" data-src="images/sliders/others/3.jpg">
				            	<div class="camera_caption fadeFromBottom">
				                    Stricken Chinese cruise ship lifted from Yangtze River
				                </div>
				            </div>
				        </div>
					</div>

					<center>
						<div class="main-bg pad-top zero-p-m">
						<blockquote class="bquote-2">
							<p >orem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus eget lacus sit amet neque posuere aliquet.orem ipsum dolor sit ame...</p>
							<span class="white">- Mark Henry "Google.com"</span>
						</blockquote>
					</div>
					</center>


					<!-- /////////////////////////////////////////////////////////////////////// -->
													<!-- Our Mission -->
					<div class="tabs-style-lg style-1 gry-bg">
							<div class="container">
								<ul class="nav nav-tabs" role="tablist">
									<li  id="presentation" role="presentation" class="active"><a class="uppercase" href="#message-5"><span><i class="fa fa-briefcase main-color tab-icon shape"></i>Principal Message</span></a></li>
									<li  id="presentation" role="presentation"><a class="uppercase" href="#mission-5"><span><i class="fa fa-briefcase main-color tab-icon shape"></i>Our Mission</span></a></li>
									<li  id="presentation" role="presentation"><a class="uppercase" href="#vision-5"><span><i class="fa fa-eye main-color tab-icon shape"></i>Our Vision</span></a></li>
									<li  id="presentation" role="presentation"><a class="uppercase" href="#strategy-5"><span><i class="fa fa-cogs main-color tab-icon shape"></i>Our Strategy</span></a></li>
								</ul>
							</div>
														
							<div class="lg-tab-content black-bg parallax" style="background-image:url('images/bgs/bg-01.jpg')" data-stellar-background-ratio="0.4" data-overlay="rgba(0,0,0,.4)">
								<div class="container">
									<div class="tab-content section">

										<div role="tabpanel" class="tab-pane fade in active" id="message-5">
												
												<div class="row">
													<div class="col-md-5">
														<img alt="" class="bordered-img shape lg main-border" src="images/features/08.jpg" />
													</div>
													<div class="col-md-7 lg-tab-txt">
														<h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
														Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa.<br> cursus massa at urnaaculis estie.Mauris in quam tristique, dignissim urna in, molestie felis.<br> Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.
													</div>
												</div>
										</div>

										<div role="tabpanel" class="tab-pane fade in" id="mission-5">
											
											<div class="row">
												<div class="col-md-5">
													<img alt="" class="bordered-img shape lg main-border" src="images/features/08.jpg" />
												</div>
												<div class="col-md-7 lg-tab-txt">
													<h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
													Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa.<br> cursus massa at urnaaculis estie.Mauris in quam tristique, dignissim urna in, molestie felis.<br> Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.
												</div>
											</div>
										</div>

										<div role="tabpanel" class="tab-pane fade" id="vision-5">
											<div class="row">
												<div class="col-md-7 lg-tab-txt">
													<h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
													<p>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce odio, molestie felis Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris.</p> 
													<ol class="f-left ollist">
														<li>vehicula imperdiet, eros est egestas odio</li>
														<li>Fusce odio, at aliquet </li>
														<li>vehicula eros est egestas odio</li>
														<li>Fusce odio, at aliquet </li>
													</ol>
												</div>
												<div class="col-md-5">
													<img alt="" class="bordered-img shape lg main-border" src="images/portfolio/masonry/2.jpg" />
												</div>
											</div>
										</div>

										<div role="tabpanel" class="tab-pane fade" id="strategy-5">
											<div class="row">
												<div class="col-md-5">
													<img alt="" class="bordered-img shape lg main-border" src="images/portfolio/masonry/4.jpg" />
												</div>
												<div class="col-md-7 lg-tab-txt">
													<h3 class="uppercase bolder main-color font-30">Hand Love Heart by the Sea</h3>
													<p>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce odio, at aliquet elit nulla sed massa Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros estMauris in quam tristique, dignissim urna in, molestie felis. Fusce tristiquetristique, elit nec vehicula imperdiet, eros estMauris.</p>
													<ul class="ullist">
														<li>vehicula imperdiet, eros est egestas odio</li>
														<li>Fusce odio, at aliquet </li>
														<li>vehicula eros est egestas odio</li>
														<li>Fusce odio, at aliquet </li>
													</ul>
												</div>
											</div>
										</div>

									</div>
								</div>
							</div>
							
						</div>
						<!-- /////////////////////Our M ission End/////////////////////////////// -->


<div class="parallax" style="background:transparent url('images/bgs/sec-bg-01.jpg')" data-stellar-background-ratio="0.6">
					<div class="container">
						<div class="row row-eq-height">
							
							<div class="col-md-3 padding-vertical-20">
								<div class="section-full-bg left main-bg rect"></div>
								<div class="white-bg bg-block main-border shape lg">
									<div class="heading sub-head">
										<h3 class="head-4 bolder uppercase">Some <span class="main-color">Facts</span></h3>
									</div>
									<p>Let’s Create Unlimited Websites With this Fancy Huge HTML Template, With Endless possibilities and very easy Customization, What else do you need to create all your websites, it is completely complete one.</p>
								</div>
							</div>
							
							<div class="col-md-9 padding-vertical-80">
								<div class="row">
									<div class="col-md-3">
										<div class="pink-bg fun-icon lg-icon shape"><i class="fa fa-users"></i></div>
										<div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="2500" data-timer="500"></div>
										<div class="fun-info t-center">Customers</div>
									</div>
									
									<div class="col-md-3">
										<div class="green-bg fun-icon lg-icon shape"><i class="fa fa-umbrella"></i></div>
										<div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="5986" data-timer="500"></div>
										<div class="fun-info t-center">Traffic</div>
									</div>
									
									<div class="col-md-3">
										<div class="blue-bg fun-icon lg-icon shape"><i class="fa fa-clock-o"></i></div>
										<div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="1960" data-timer="500"></div>
										<div class="fun-info t-center">Working Hours</div>
									</div>
									
									<div class="col-md-3">
										<div class="orange-bg fun-icon lg-icon shape"><i class="fa fa-coffee"></i></div>
										<div class="fun-number t-center heavy-font odometer main-color" data-initial="0" data-value="250" data-timer="500"></div>
										<div class="fun-info t-center">Cofee Cups</div>
									</div>
									
								</div>
							</div>
							
						</div>
					</div>
				</div>
								

					<!-- \\\\\\\\\\\\\\\\\\\\\\\\\INTRODUCTION\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ -->
		    		<div class="section gry-bg">
						<div class="container">
							<div class="row">
								<div class="col-md-3">
									<div class="team-box box-2 shape lg">
										<div class="team-img">
											<span></span>
											<img alt="" src="assets/images/people/1.jpg" />
											<div class="box-socials">
												<ul class="social-list">
												    <li><a href="#" class="fa fa-dribbble shape sm"></a></li>
												    <li><a href="#" class="fa fa-facebook shape sm"></a></li>
												    <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
												    <li><a href="#" class="fa fa-twitter shape sm"></a></li>
											    </ul>
											</div>
										</div>
										<div class="team-details">
											<h3 class="team-name">Mohamed Abdelfattah</h3>
											<h5 class="team-pos main-color">Founder</h5>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-box box-2 shape lg">
										<div class="team-img">
											<span></span>
											<img alt="" src="assets/images/people/2.jpg" />
											<div class="box-socials">
												<ul class="social-list">
												    <li><a href="#" class="fa fa-dribbble shape sm"></a></li>
												    <li><a href="#" class="fa fa-facebook shape sm"></a></li>
												    <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
												    <li><a href="#" class="fa fa-twitter shape sm"></a></li>
											    </ul>
											</div>
										</div>
										<div class="team-details">
											<h3 class="team-name">Lina Mohamed</h3>
											<h5 class="team-pos main-color">Producer</h5>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-box box-2 shape lg">
										<div class="team-img">
											<span></span>
											<img alt="" src="assets/images/people/3.jpg" />
											<div class="box-socials">
												<ul class="social-list">
												    <li><a href="#" class="fa fa-dribbble shape sm"></a></li>
												    <li><a href="#" class="fa fa-facebook shape sm"></a></li>
												    <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
												    <li><a href="#" class="fa fa-twitter shape sm"></a></li>
											    </ul>
											</div>
										</div>
										<div class="team-details">
											<h3 class="team-name">Eyad Mohamed</h3>
											<h5 class="team-pos main-color">Director</h5>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-box box-2 shape lg">
										<div class="team-img">
											<span></span>
											<img alt="" src="assets/images/people/4.jpg" />
											<div class="box-socials">
												<ul class="social-list">
												    <li><a href="#" class="fa fa-dribbble shape sm"></a></li>
												    <li><a href="#" class="fa fa-facebook shape sm"></a></li>
												    <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
												    <li><a href="#" class="fa fa-twitter shape sm"></a></li>
											    </ul>
											</div>
										</div>
										<div class="team-details">
											<h3 class="team-name">Lara Jones</h3>
											<h5 class="team-pos main-color">Sales Manager</h5>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
			    </div>			    
		    	
		    	<!-- Footer start -->
			    <footer id="footWrapper">
			    	<div class="footer-top main-bg">
			    		<div class="container">
							<div id="twitter-feed" class="slick-s shape"></div>
			    		</div>
			    	</div>
			    	<div class="footer-middle">
					    <div class="container">
						    <div class="row">
						    	
						    	<!-- main menu footer cell start -->
							    <div class="col-md-3 first">
								    <h3>Main Menu</h3>
								    <ul class="menu-widget">
									    <li><a href="home.html">Home Page</a></li>
									    <li><a href="about-us.html">About Us</a></li>
									    <li><a href="blog.html">Our Blog</a></li>
									    <li><a href="portfolio-grid-4-cols.html">Our Portfolio</a></li>
									    <li><a href="FAQ.html">FAQ</a></li>
								    </ul>
							    </div>
							    <!-- main menu footer cell start -->
							    
							    <!-- Our Friends footer cell start -->
							    <div class="col-md-3">
							    	<h3>Flickr Photos</h3>
							    	<p>You can checkout some of our amazing photos on flickr. </p>
							    	<!-- <ul id="flickrFeed" class="flickr-widget"></ul> -->
							    </div>
							    <!-- Our Friends footer cell start -->
							    
							    <!-- Useful Links footer cell start -->
							    <div class="col-md-3">
							    	<h3>Tags Cloud</h3>
							    	<ul class="tags hover-effect">
								    	<li class="shape sm"><a href="#" data-hover="Clean">Clean</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Design">Design</a></li>
								    	<li class="shape sm"><a href="#" data-hover="User interface">User interface</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Performance">Performance</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Development">Development</a></li>
								    	<li class="shape sm"><a href="#" data-hover="WordPress">WordPress</a></li>
								    	<li class="shape sm"><a href="#" data-hover="ThemeForest">ThemeForest</a></li>
								    	<li class="shape sm"><a href="#" data-hover="SEO">SEO</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Joomla">Joomla</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Popular">Popular</a></li>
								    	<li class="shape sm"><a href="#" data-hover="ASP.Net">ASP.Net</a></li>
								    	<li class="shape sm"><a href="#" data-hover="SharePoint">SharePoint</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Bootstrap">Bootstrap</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Joomla">HTML5</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Popular">Responsive</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Joomla">Visual</a></li>
								    	<li class="shape sm"><a href="#" data-hover="Popular">Studio</a></li>
								    </ul>
							    </div>
							    <!-- Useful Links footer cell start -->
							    
							    <!-- Tags Cloud footer cell start -->
							    <div class="col-md-3 last contact-widget">
								    <h3>Contact Us</h3>
								    <ul class="details">
								    	<li><i class="fa fa-map-marker shape"></i><span><span class="heavy-font">Headquarters: </span>123 Street Name, City, Country.</span></li>
								    	<li><i class="fa fa-envelope shape"></i><span><span class="heavy-font">Email: </span>e-mail@company.com</span></li>
								    	<li><i class="fa fa-phone shape"></i><span><span class="heavy-font">Tel: </span>+1(888)000-0000</span></li>
								    	<li><i class="fa fa-skype shape"></i><span><span class="heavy-font">Skype: </span>our_skype_account</span></li>
								    </ul>
							    </div>
							    <!-- Tags Cloud footer cell start -->
							    
							    <div class="clearfix margin-bottom-30"></div>
							    							    							    
						    </div>
						    
						    <div class="bottom-md-footer">
							    
							    <div class="col-md-7">
								    <label>Follow Us On:</label>
								    <ul class="social-list">
									    <li><a data-toggle="tooltip" data-placement="top" title="Dribbble" href="#" class="fa fa-dribbble shape sm">dribbble</a></li>
									    <li><a data-toggle="tooltip" data-placement="top" title="Facebook" href="#" class="fa fa-facebook shape sm">facebook</a></li>
									    <li><a data-toggle="tooltip" data-placement="top" title="Linkedin" href="#" class="fa fa-linkedin shape sm">linkedin</a></li>
									    <li><a data-toggle="tooltip" data-placement="top" title="Skype" href="#" class="fa fa-skype shape sm">skype</a></li>
									    <li><a data-toggle="tooltip" data-placement="top" title="Twitter" href="#" class="fa fa-twitter shape sm">twitter</a></li>
									    <li><a data-toggle="tooltip" data-placement="top" title="Behance" href="#" class="fa fa-behance shape sm">twitter</a></li>
								    </ul>
							    </div>
						    	
							    
							    <div class="f-right col-md-5 nl">
							    	<form action="http://it-rays.us9.list-manage.com/subscribe/post-json?u=8ff98fda7c9727d2b65a45ac2&amp;id=29d0e843d7&amp;c=?" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank" novalidate class="NL">
							    		
							    		<label>Subscribe to our NewsLetters:</label>
							    		
							    		<input class="form-control shape" type="email" value="" name="EMAIL" id="mce-EMAIL" placeholder="Enter your email here" required />
							    		
							    		<input type="submit" name="subscribe" id="mc-embedded-subscribe" class="btn main-bg shape" value="Subscribe" />
							    		
							    		<div class="hidden"><input type="text" name="b_8ff98fda7c9727d2b65a45ac2_29d0e843d7" value=""></div>
							    		
		   								 <div class="nl-note"><span></span></div>
		   								 
							    	</form>
							    </div>
							    
						    </div>
						    
					    </div>	
				    </div>
				    			    
				    <!-- footer bottom bar start -->
				    <div class="footer-bottom">
					    <div class="container">
				    		<div class="row">
					    		<!-- footer copyrights left cell -->
					    		<div class="copyrights col-md-5 first">© Copyrights <b class="main-color">SuperFine</b> 2015. All rights reserved.</div>
					    						    		
					    		<!-- footer social links right cell start -->
							    <div class="col-md-7 last">
							    	<ul class="footer-menu f-right">
									    <li><a href="#">Home</a></li>
									    <li><a href="#">About</a></li>
									    <li><a href="#">Services</a></li>
									    <li><a href="#">Blog</a></li>
									    <li><a href="#">Contact</a></li>
								    </ul>
							    </div>
							    <!-- footer social links right cell end -->
							    
				    		</div>
					    </div>
				    </div>
				    <!-- footer bottom bar end -->
				</footer>
		    	<!-- Footer end -->
		    </div>
		</div>
				
		<!-- Modal -->
		<div class="modal fade" id="registermodal" tabindex="-1" role="dialog" aria-labelledby="registermodal">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title" id="gridSystemModalLabel">Create New Account</h4>
		      </div>
		      <div class="modal-body">
		        <div class="padding-horizontal-20 padding-vertical-20">
		            	<p>Hello our valued visitor, We present you the best web solutions and high quality graphic designs with a lot of features. just login to your account and enjoy ...</p>
						<div class="login-controls">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="User name" />
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Email" />
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Confirm Email" />
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Password" />
							</div>
							<div class="form-group">
								<input type="password" class="form-control" placeholder="Confirm Password" />
							</div>
							<div class="form-group floated-controls">
								<span class="block checkbox-block"><input type="checkbox" class="checkbox" /> <span>I Agree !</span></span>
							</div>
						</div>
		        </div>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn main-bg">Submit</button>
		        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		      </div>
		    </div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
		    	
		<!-- Back to top Link -->
	    <a id="to-top"><span class="fa fa-chevron-up shape main-bg"></span></a>


	    <!-- Load JS plugins file -->
 		<script type="text/javascript" src="js/assets.min.js"></script>
				
		<!-- general script file -->
		<script type="text/javascript" src="js/script.js"></script>
		
	</body>

</html>