<?php $__env->startSection('content'); ?>
 <div class="pageContent">
             <div class="page-title title-5">
                  <div class="container">
                     <div class="row">
                        <h1 class="shape">Senior Faculty</h1>
                        <h3 class="shape black">This is sub heading text to describe the page functionality</h3>
                        <div class="breadcrumbs white-bg">
                           <a href="#">Home</a><i class="fa fa-long-arrow-right main-color"></i><a href="#">Pages</a><i class="fa fa-long-arrow-right main-color"></i><span>Centered Page Title</span>
                        </div>
                     </div>
                  </div>
               </div>
               
               <div class="section gry-bg">
                  <div class="container">

                     <div class="row">

                      <div class="page-title title-5">          <h1 class="shape">Maths Department</h1></div>
                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/ahmer_ali_qaiser.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/ahmer_ali_qaiser.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Ahmer Ali Qaiser</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/muhammad_izhar.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/muhammad_izhar.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Muhammad Izhar</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/muneeb_hassan.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/muneeb_hassan.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Muneeb Hassan</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/manzoor_ahmed.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/manzoor_ahmed.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Manzoor Ahmed</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>
                     </div>

                  </div>
               </div>

                <div class="section gry-bg" style="padding-top: 0px; margin-top: 0px">
                  <div class="container">

                     <div class="row" >

                      <div class="page-title title-5">          <h1 class="shape">English Department</h1></div>
                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/ahmer_ali_qaiser.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/ahmer_ali_qaiser.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Ahmer Ali Qaiser</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/muhammad_izhar.jpg" />

                                  <span class="hover-fact"> Bs Computer Science
                                 B.Ed, M.Ed</span>
                                 <div class="box-socials">

                                    <ul class="social-list">


                                       <li><a href="images/team/muhammad_izhar.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Muhammad Izhar</h3>
                                 <h5 class="team-pos team-desig">MS Computer Science <br>
                                

                                 </h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/muneeb_hassan.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/muneeb_hassan.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Muneeb Hassan</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/manzoor_ahmed.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/manzoor_ahmed.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Manzoor Ahmed</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                         <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/manzoor_ahmed.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/manzoor_ahmed.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Manzoor Ahmed</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>

                         <div class="col-md-3">
                           <div class="team-box box-2 shape-img lg">
                              <div class="team-img">
                                 <span></span>
                                 <img alt="" src="images/team/thm/manzoor_ahmed.jpg" />
                                 <div class="box-socials">
                                    <ul class="social-list">

                                       <li><a href="images/team/manzoor_ahmed.jpg" class="zoom shape new-angle fa fa-search-plus"></a></li>
                                       <li><a href="#" class="fa fa-facebook shape sm"></a></li>
                                       <li><a href="#" class="fa fa-linkedin shape sm"></a></li>
                                       <li><a href="#" class="fa fa-twitter shape sm"></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="team-details ">
                                 <h3 class="team-name">Manzoor Ahmed</h3>
                                 <h5 class="team-pos team-desig">Sales Manager</h5>
                              </div>
                           </div>
                        </div>
                     </div>

                  </div>
               </div>
        <iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FVocativ%2Fvideos%2F1229612317051001%2F&show_text=0&width=560" width="560" height="315" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>